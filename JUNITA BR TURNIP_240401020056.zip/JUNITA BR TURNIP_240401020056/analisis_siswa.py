
# -*- coding: utf-8 -*-
# ANALISIS DATA SISWA - EDA, REGRESI, CLUSTERING, KLASIFIKASI

import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.linear_model import LinearRegression
from sklearn.cluster import KMeans
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split
from sklearn.tree import DecisionTreeClassifier
from sklearn.metrics import classification_report, confusion_matrix

# Load data
df = pd.read_csv("student-mat.csv", sep=';')

# ========================
# 1. EDA (Exploratory Data Analysis)
# ========================
print("=== Informasi Data ===")
print(df.info())

print("\n=== Statistik Deskriptif ===")
print(df.describe())

print("\n=== Missing Values ===")
print(df.isnull().sum())

# Korelasi numerik
plt.figure(figsize=(10, 8))
sns.heatmap(df.corr(numeric_only=True), annot=True, cmap="coolwarm")
plt.title("Korelasi Antar Variabel Numerik")
plt.tight_layout()
plt.savefig("eda_korelasi.png")
plt.close()

# Distribusi nilai akhir (G3)
plt.hist(df["G3"], bins=10, edgecolor='black')
plt.title("Distribusi Nilai Akhir (G3)")
plt.xlabel("Nilai G3")
plt.ylabel("Jumlah Siswa")
plt.savefig("eda_histogram_g3.png")
plt.close()

# ========================
# 2. Regresi Linear
# ========================
# Variabel bebas: studytime dan absences, Target: G3
X_reg = df[["studytime", "absences"]]
y_reg = df["G3"]

model = LinearRegression()
model.fit(X_reg, y_reg)
print("\n=== Hasil Regresi Linear ===")
print(f"Koefisien: {model.coef_}")
print(f"Intercept: {model.intercept_}")
print(f"R^2 Score: {model.score(X_reg, y_reg):.2f}")

# Visualisasi
plt.scatter(df["studytime"], df["G3"])
plt.xlabel("Waktu Belajar")
plt.ylabel("Nilai G3")
plt.title("Regresi Linear: Studytime vs G3")
plt.savefig("regresi_studytime.png")
plt.close()

# ========================
# 3. Clustering (KMeans)
# ========================
X_clust = df[["absences", "studytime"]]
scaler = StandardScaler()
X_scaled = scaler.fit_transform(X_clust)

kmeans = KMeans(n_clusters=3, random_state=42, n_init=10)
df["cluster"] = kmeans.fit_predict(X_scaled)

plt.figure(figsize=(8,6))
sns.scatterplot(x="absences", y="studytime", hue="cluster", data=df, palette="Set2")
plt.title("Clustering Siswa Berdasarkan Absensi & Waktu Belajar")
plt.savefig("clustering_absensi_studytime.png")
plt.close()

# ========================
# 4. Klasifikasi
# ========================
# Target: kategori_nilai
df["kategori_nilai"] = pd.cut(df["G3"], bins=[-1, 9, 14, 20], labels=["kurang", "sedang", "baik"])

X_cls = df[["absences", "studytime", "failures"]]
y_cls = df["kategori_nilai"]

X_train, X_test, y_train, y_test = train_test_split(X_cls, y_cls, test_size=0.3, random_state=42)

clf = DecisionTreeClassifier(random_state=42)
clf.fit(X_train, y_train)
y_pred = clf.predict(X_test)

print("\n=== Classification Report ===")
print(classification_report(y_test, y_pred))
print("\n=== Confusion Matrix ===")
print(confusion_matrix(y_test, y_pred))

# Visualisasi hasil klasifikasi
from sklearn.tree import plot_tree
plt.figure(figsize=(12, 8))
plot_tree(clf, feature_names=X_cls.columns, class_names=clf.classes_, filled=True)
plt.title("Pohon Keputusan Klasifikasi Nilai Siswa")
plt.savefig("klasifikasi_tree.png")
plt.close()
